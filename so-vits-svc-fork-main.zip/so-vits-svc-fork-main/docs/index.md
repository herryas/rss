# Welcome to SoftVC VITS Singing Voice Conversion Fork documentation!

```{toctree}
:caption: Installation & Usage
:maxdepth: 2

installation
usage
```

```{toctree}
:caption: Project Info
:maxdepth: 2

changelog
contributing
```

```{toctree}
:caption: API Reference
:maxdepth: 2

so_vits_svc_fork
```

```{include} ../README.md

```
