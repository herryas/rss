__version__ = "3.14.1"

from .logger import init_logger

init_logger()
